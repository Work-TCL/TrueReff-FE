document.addEventListener('DOMContentLoaded', function () {
    // Find all buttons with the class 'copy-btn'
    const copyButtons = document.querySelectorAll('.copy-btn');

    copyButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();

            // Get the ID of the input field to copy from the button's data attribute
            const targetInputId = this.getAttribute('data-target');
            const inputToCopy = document.querySelector(targetInputId);

            if (inputToCopy) {
                // Use the modern, secure Clipboard API
                navigator.clipboard.writeText(inputToCopy.value).then(() => {
                    // Provide user feedback
                    const originalText = this.textContent;
                    this.textContent = 'Copied!';
                    
                    // Revert the button text after 2 seconds
                    setTimeout(() => {
                        this.textContent = originalText;
                    }, 2000);
                }).catch(err => {
                    console.error('Failed to copy text: ', err);
                });
            }
        });
    });
});