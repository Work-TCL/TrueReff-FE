jQuery(function ($) {
    

    function getFieldValue(selector) {
        const $el = $(selector);
        return $el.length ? $el.val() : '';
    }

    // function sendAbandonedWebhook() {

    //     const payload = {
    //         action: 'crm_abandoned_checkout',
    //         nonce: crm_ajax_data.nonce,
    //         billing_first_name: getFieldValue('#billing-first_name'),
    //         billing_last_name: getFieldValue('#billing-last_name'),
    //         billing_email: getFieldValue('#email'),
    //         billing_phone: getFieldValue('#billing-phone'),
    //         billing_address_1: getFieldValue('#billing_address_1'),
    //         billing_address_2: getFieldValue('#billing_address_2'),
    //         billing_city: getFieldValue('#billing_city'),
    //         billing_postcode: getFieldValue('#billing_postcode'),
    //         billing_state: getFieldValue('#billing_state'),
    //         billing_country: getFieldValue('#billing_country'),
    //         shipping_first_name: getFieldValue('#shipping_first_name'),
    //         shipping_last_name: getFieldValue('#shipping_last_name'),
    //         shipping_address_1: getFieldValue('#shipping_address_1'),
    //         shipping_address_2: getFieldValue('#shipping_address_2'),
    //         shipping_city: getFieldValue('#shipping_city'),
    //         shipping_postcode: getFieldValue('#shipping_postcode'),
    //         shipping_state: getFieldValue('#shipping_state'),
    //         shipping_country: getFieldValue('#shipping_country'),
    //     };

    //     $.post(crm_ajax_data.ajax_url, payload, function(response) {
    //         console.log('Webhook AJAX response:', response);
    //     });
    // }
    function sendAbandonedWebhook() {
        const $form = $('form.wc-block-components-form').first();

        // If the form isn't on the page for some reason, do nothing.
        if (!$form.length) {
            console.error('CRM Webhook: Could not find the WooCommerce checkout form.');
            return;
        }

        const data = {
            action: 'crm_abandoned_checkout',
            nonce: crm_ajax_data.nonce
        };

        $form.find('input, select, textarea').each(function () {
            const $field = $(this);
            const name = $field.attr('name') || $field.attr('id');
            if (!name) return;
    
            let value = $field.val();
    
            if ($field.is(':checkbox') || $field.is(':radio')) {
                if (!$field.is(':checked')) return;
            }
    
            data[name] = value;
        });

        // Send all the data to your WordPress AJAX handler.
        $.post(crm_ajax_data.ajax_url, data, function(response) {
            console.log('Webhook AJAX response:', response);
        });
    }

    $(document.body).on('focusout', 'form.wc-block-components-form input', function () {

        const email = getFieldValue('#email');
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

        if (email && emailRegex.test(email)) {
            console.log('l')
            sendAbandonedWebhook();
        } else {
            console.log('Email field is not yet valid. Waiting...');
        }
    });
});
