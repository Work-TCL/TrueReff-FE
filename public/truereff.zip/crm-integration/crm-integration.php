<?php

/**
 * Plugin Name:       CRM Integration for WooCommerce
 * Description:       Connects WooCommerce with an external CRM to sync products and generate trackable links.
 * Version:           1.0.0
 * Author:            TCL
 * Author URI:        https://your-website.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       crm-integration
 * Requires at least: 5.6
 * Requires PHP:      8.2
 * WC requires at least: 6.0
 * WC tested up to: 8.0
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * The main class for the plugin.
 */
final class CRM_Integration_Plugin
{
    /**
     * The single instance of the class.
     */
    protected static $_instance = null;

    /**
     * Main Plugin Instance.
     * Ensures only one instance of the plugin is loaded.
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor.
     */
    public function __construct()
    {
        register_activation_hook(__FILE__, [$this, 'on_activation']);
        // This action hook runs when all plugins are loaded.
        add_action('plugins_loaded', [$this, 'init']);

        add_action('admin_menu', [$this, 'add_admin_menu_page']);

        add_action('admin_init', [$this, 'redirect_on_activation']);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);

        register_deactivation_hook(__FILE__, [$this, 'on_deactivation']);

        add_action('template_redirect', [$this, 'handle_custom_checkout_link']);

        // hooks for webhook call
        add_action('woocommerce_new_order', [$this, 'trigger_order_placed_webhook']);
        add_action('woocommerce_order_status_completed', [$this, 'trigger_order_status_webhook']);
        add_action('woocommerce_order_status_cancelled', [$this, 'trigger_order_status_webhook']);
        add_action('woocommerce_order_fully_refunded', [$this, 'trigger_order_status_webhook']);

        add_action('init', [$this, 'crm_check_checkout_utm_and_trigger_webhook']);


        // add_action('woocommerce_checkout_update_order_review', [$this,'crm_send_abandoned_checkout_webhook']);
        add_action('wp_enqueue_scripts', function () {
            if (is_checkout()) {
                wp_enqueue_script('crm-checkout-webhook', plugin_dir_url(__FILE__) . 'assets/js/crm-checkout-webhook.js', ['jquery'], null, true);
                wp_localize_script('crm-checkout-webhook', 'crm_ajax_data', [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('crm_checkout_nonce'),
                ]);
            }
        });

        add_action('wp_ajax_crm_abandoned_checkout', [$this, 'crm_handle_abandoned_checkout']);
        add_action('wp_ajax_nopriv_crm_abandoned_checkout', [$this, 'crm_handle_abandoned_checkout']);
    }

    public function on_activation()
    {
        // The 'is_plugin_active' function is not available on the front-end,
        // so we need to include the file that contains it.
        // This is a best practice for activation hooks.
        if (!function_exists('is_plugin_active')) {
            include_once (ABSPATH . 'wp-admin/includes/plugin.php');
        }

        // Check if WooCommerce is active. The path is critical.
        if (!is_plugin_active('woocommerce/woocommerce.php')) {
            // If not active, immediately deactivate our own plugin.
            deactivate_plugins(plugin_basename(__FILE__));

            // And display a helpful error message to the user. wp_die() stops execution.
            wp_die(
                __('<strong>CRM Integration Plugin Error:</strong> This plugin requires <strong>WooCommerce</strong> to be installed and active. Please activate WooCommerce first, and then try activating this plugin again.', 'crm-integration'),
                __('Plugin Activation Error', 'crm-integration'),
                ['back_link' => true]  // Provides a "Go Back" link
            );
        }

        $this->create_link_clicks_table();

        set_transient('crm_integration_activation_redirect', true, 30);

        flush_rewrite_rules();
    }

    private function create_link_clicks_table()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'crm_link_clicks';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            link_id varchar(55) NOT NULL,
            crm_affiliate_id varchar(255) NOT NULL,
            product_id bigint(20) NOT NULL,
            coupon_code varchar(100) DEFAULT NULL,
            click_count int(11) NOT NULL DEFAULT 0,
            created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY link_id (link_id)
        ) $charset_collate;";

        // We need to load the dbDelta function
        require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function on_deactivation()
    {
        flush_rewrite_rules();
    }

    public function redirect_on_activation()
    {
        if (get_transient('crm_integration_activation_redirect')) {
            delete_transient('crm_integration_activation_redirect');

            update_option('crm_integration_shop_url', home_url('/'));
            if (function_exists('wp_generate_uuid4')) {
                update_option('crm_integration_unique_id', wp_generate_uuid4());
            } else {
                // Fallback for older WordPress versions
                update_option('crm_integration_unique_id', 'uid_' . md5(uniqid(rand(), true)));
            }
            update_option('crm_integration_is_active', false);

            // Redirect to our new settings page
            $redirect_url = admin_url('options-general.php?page=crm-integration-settings');

            // Redirect and immediately stop script execution
            wp_safe_redirect($redirect_url);
            exit;
        }
    }

    /**
     * Initialize the plugin.
     * Check for WooCommerce and load other components.
     */
    public function init()
    {
        // === REQUIREMENT 1: CHECK IF WOOCOMMERCE IS ACTIVE ===
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', [$this, 'woocommerce_not_active_notice']);
            return;  // Stop the plugin from loading further.
        }

        // If WooCommerce is active, we can proceed.
        $this->setup_api();
    }

    public function add_admin_menu_page()
    {
        add_options_page(
            'CRM Integration Settings',  // Page Title
            'CRM Integration',  // Menu Title
            'manage_options',  // Capability required to see this menu
            'crm-integration-settings',  // Menu Slug (unique identifier)
            [$this, 'render_settings_page']  // Function that renders the page HTML
        );
    }

    public function render_settings_page()
    {
        // Check if the user has the required capability
        if (!current_user_can('manage_options')) {
            return;
        }

        // Retrieve the saved data
        $shop_url = get_option('crm_integration_shop_url', '');
        $unique_id = get_option('crm_integration_unique_id', '');
        $is_active = get_option('crm_integration_is_active', false);
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <p>Use the details below to connect your CRM. The connection is established by calling the <strong>/connect</strong> API endpoint.</p>
            
             <table class="form-table" role="presentation">
                <tbody>
                    <!-- NEW: Connection Status Row -->
                    <tr>
                        <th scope="row">Connection Status</th>
                        <td>
                            <?php if ($is_active): ?>
                                <span style="color: #227122; font-weight: bold;">Connected</span>
                            <?php else: ?>
                                <span style="color: #d63638; font-weight: bold;">Not Connected</span>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><label for="crm-shop-url">Shop URL</label></th>
                        <td>
                            <input type="text" id="crm-shop-url" readonly value="<?php echo esc_attr($shop_url); ?>" class="regular-text" />
                            <button class="button button-secondary copy-btn" data-target="#crm-shop-url">Copy</button>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="crm-unique-id">Unique ID</label></th>
                        <td>
                            <input type="text" id="crm-unique-id" readonly value="<?php echo esc_attr($unique_id); ?>" class="regular-text" />
                            <button class="button button-secondary copy-btn" data-target="#crm-unique-id">Copy</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function enqueue_admin_scripts($hook_suffix)
    {
        // The hook_suffix for our page is 'settings_page_crm-integration-settings'
        // We check this so our script doesn't load on every admin page.
        if ('settings_page_crm-integration-settings' !== $hook_suffix) {
            return;
        }

        // Enqueue our script
        wp_enqueue_script(
            'crm-integration-admin-script',  // A unique handle for the script
            plugin_dir_url(__FILE__) . 'assets/js/admin.js',  // Path to the file
            [],  // Dependencies (e.g., 'jquery')
            '1.0.0',  // Version number
            true  // Load in the footer
        );
    }

    /**
     * Display an admin notice if WooCommerce is not active.
     */
    public function woocommerce_not_active_notice()
    {
        ?>
        <div class="error">
            <p><?php _e('<strong>CRM Integration Plugin</strong> requires WooCommerce to be installed and active.', 'crm-integration'); ?></p>
        </div>
        <?php
    }

    /**
     * Setup the REST API endpoints.
     */
    public function setup_api()
    {
        // The 'rest_api_init' action is where we register our custom routes.
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Register all custom REST API routes for the plugin.
     */
    public function register_routes()
    {
        $namespace = 'crm-integration';
        register_rest_route($namespace, '/connect', [
            'methods' => WP_REST_Server::CREATABLE,  // This is 'POST'
            'callback' => [$this, 'connect_crm_callback'],
            // 'permission_callback' => [ $this, 'check_api_key_permission' ],
            'args' => [
                'shopUrl' => [
                    'required' => true,
                    'validate_callback' => 'esc_url_raw',  // Basic URL validation
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'uniqueId' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ]);

        register_rest_route($namespace, '/products', [
            'methods' => WP_REST_Server::READABLE,  // This is 'GET'
            'callback' => [$this, 'get_products_callback'],
            'permission_callback' => [$this, 'check_token_validate'],
        ]);

        register_rest_route($namespace, '/products/(?P<id>[\d]+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_product_callback'],
            'permission_callback' => [$this, 'check_token_validate'],
            'args' => [
                'id' => [
                    'validate_callback' => function ($param, $request, $key) {
                        return is_numeric($param);
                    }
                ],
            ],
        ]);

        register_rest_route($namespace, '/links/generate', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'generate_link_callback'],
            'permission_callback' => [$this, 'check_token_validate'],
            'args' => [
                'productIdentifier' => ['required' => true],
                'identifierType' => ['required' => true, 'default' => 'id'],
                'crmAffiliateId' => ['required' => true]
            ]
        ]);

        register_rest_route($namespace, '/links/update-trackable-link-with-coupon', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'update_link_callback'],
            'permission_callback' => [$this, 'check_token_validate'],
            'args' => [
                'productIdentifier' => ['required' => true],
                'identifierType' => ['required' => true, 'default' => 'id'],
                'crmAffiliateId' => ['required' => true],
                'linkId' => ['required' => true]
            ]
        ]);

        register_rest_route($namespace, '/analytics/link-stats', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_link_stats_callback'],
            'permission_callback' => [$this, 'check_token_validate'],
            'args' => [
                'link_ids' => [
                    'required' => true,
                    'description' => 'A comma-separated string of link IDs to retrieve stats for.',
                    'type' => 'string',
                    'validate_callback' => function ($param, $request, $key) {
                        return !empty($param);
                    }
                ],
            ],
        ]);

        register_rest_route($namespace, '/analytics/affiliate-total-visits', [
            'methods' => WP_REST_Server::READABLE,  // GET
            'callback' => [$this, 'get_affiliate_stats_callback'],
            'permission_callback' => [$this, 'check_token_validate'],
            'args' => [
                'affiliate_id' => [
                    'description' => 'The unique ID of the CRM affiliate.',
                    'type' => 'string',
                    'required' => true,
                ],
            ],
        ]);
    }

    public function check_token_validate($request)
    {
        $request_token = $request->get_param('token');
        $access_token = get_option('crm_integration_access_token');

        if (!$access_token || !$request_token || !hash_equals($access_token, $request_token)) {
            return new WP_Error('rest_forbidden', 'Invalid Token.', ['status' => 401]);
        }

        return true;
    }

    public function connect_crm_callback($request)
    {
        $incoming_shop_url = trailingslashit($request['shopUrl']);
        $incoming_unique_id = $request['uniqueId'];

        $stored_shop_url = trailingslashit(get_option('crm_integration_shop_url'));
        $stored_unique_id = get_option('crm_integration_unique_id');

        if ($incoming_shop_url === $stored_shop_url && $incoming_unique_id === $stored_unique_id) {
            // If they match, update the status to active
            update_option('crm_integration_is_active', true);

            $token = bin2hex(random_bytes(32));
            update_option('crm_integration_access_token', $token);

            return new WP_REST_Response([
                'success' => true,
                'message' => 'CRM connected and validated successfully.',
                'token' => $token,
            ], 200);
        } else {
            // If they don't match, set status to inactive and return an error
            update_option('crm_integration_is_active', false);

            return new WP_Error(
                'crm_connection_failed',
                'Connection details do not match. Please verify the Shop URL and Unique ID.',
                ['status' => 400]  // 400 Bad Request is appropriate here
            );
        }
    }

    public function get_products_callback($request)
    {
        // 1. Get parameters from the request
        $page = $request->get_param('page') ? absint($request->get_param('page')) : 1;
        $per_page = $request->get_param('limit') ? absint($request->get_param('limit')) : 50;

        // 2. Query WooCommerce for products with pagination enabled
        $args = [
            'status' => 'publish',
            'limit' => $per_page,
            'page' => $page,
            'paginate' => true,  // This is the key that returns pagination data
            'return' => 'objects',
        ];

        $result = wc_get_products($args);

        // 3. Extract the data from the result object
        $products_on_page = $result->products;
        $total_products = $result->total;
        $total_pages = $result->max_num_pages;

        // 4. Format the products for the API response
        $formatted_products = [];
        foreach ($products_on_page as $product) {
            $formatted_products[] = $this->format_product_data($product);
        }

        // 5. Build the final response with the exact structure you want
        $response_data = [
            'products' => $formatted_products,
            'pagination' => [
                'totalProducts' => (int) $total_products,
                'totalPages' => (int) $total_pages,
                'currentPage' => (int) $page,
                'limit' => (int) $per_page,
                'hasNextPage' => $page < $total_pages,  // Boolean check
                'hasPrevPage' => $page > 1,  // Boolean check
            ],
        ];

        return new WP_REST_Response($response_data, 200);
    }

    public function get_product_callback($request)
    {
        $product_id = (int) $request['id'];
        $product = wc_get_product($product_id);

        if (!$product || 'publish' !== $product->get_status()) {
            return new WP_Error('rest_product_invalid', 'Product not found.', ['status' => 404]);
        }

        $data = [
            'id'            => $product->get_id(),
            'name'          => $product->get_name(),
            'slug'          => $product->get_slug(),
            'type'          => $product->get_type(),
            'status'        => $product->get_status(),
            'sku'           => $product->get_sku(),
            'price'         => $product->get_price(),
            'regular_price' => $product->get_regular_price(),
            'sale_price'    => $product->get_sale_price(),
            'description'   => $product->get_description(),
            'short_desc'    => $product->get_short_description(),
            'stock_status'  => $product->get_stock_status(),
            'stock_quantity'=> $product->get_stock_quantity(),
            'categories'    => wp_get_post_terms($product_id, 'product_cat', ['fields' => 'names']),
            'images'        => [],
            'attributes'    => [],
            'variations'    => [],
        ];

        // Images
        $image_id = $product->get_image_id();
        if ($image_id) {
            $data['images'][] = wp_get_attachment_url($image_id);
        }

        // Gallery Images
        $gallery_image_ids = $product->get_gallery_image_ids();
        foreach ($gallery_image_ids as $gallery_id) {
            $data['images'][] = wp_get_attachment_url($gallery_id);
        }

        // Attributes
        foreach ($product->get_attributes() as $attribute) {
            $name = $attribute->get_name();
            $options = [];
        
            if ($attribute->is_taxonomy()) {
                // Taxonomy-based attribute (e.g., pa_color)
                $terms = wp_get_post_terms($product_id, $name);
                foreach ($terms as $term) {
                    $options[] = $term->name;
                }
            } else {
                // Custom product attribute
                $options = $attribute->get_options();
            }
            $data['attributes'][] = [
                'name'   => $attribute->get_name(),
                'options'   => $options,
                'visible' => $attribute->get_visible(),
                'variation' => $attribute->get_variation(),
            ];
        }

        // Variations (for variable product)
        if ($product->is_type('variable')) {
            $variation_ids = $product->get_children();
            foreach ($variation_ids as $vid) {
                $variation = wc_get_product($vid);
                $data['variations'][] = [
                    'id'            => $variation->get_id(),
                    'sku'           => $variation->get_sku(),
                    'price'         => $variation->get_price(),
                    'regular_price' => $variation->get_regular_price(),
                    'sale_price'    => $variation->get_sale_price(),
                    'attributes'    => $variation->get_attributes(),
                    'stock_status'  => $variation->get_stock_status(),
                    'stock_quantity'=> $variation->get_stock_quantity(),
                    'image'         => wp_get_attachment_url($variation->get_image_id()),
                ];
            }
        }

        return new WP_REST_Response($data, 200);
    }


    private function format_product_data($product)
    {
        $categories = wp_get_post_terms($product->get_id(), 'product_cat');
        $main_category = isset($categories[0]) ? $categories[0]->name : '';
        $sub_category = isset($categories[1]) ? $categories[1]->name : '';

        // Count total variants
        $total_variants = 0;
        if ($product->is_type('variable')) {
            $total_variants = count($product->get_children());
        }

        // Status mapping
        $status_map = [
            'publish' => 'active',
            'draft' => 'inactive',
            'pending' => 'pending',
        ];
        $status = $product->get_status();
        $status_label = $status_map[$status] ?? $status;

        return [
            'id' => (int) $product->get_id(),
            'name' => $product->get_name(),
            'handle' => $product->get_slug(),
            'category' => $main_category,
            'sub_category' => $sub_category,
            'price' => (string) $product->get_price(),
            'main_image' => get_the_post_thumbnail_url($product->get_id(), 'full'),
            'total_variants' => $total_variants,
            'status' => $status_label,
        ];
    }

    public function generate_link_callback($request)
    {
        // --- 1. Sanitize and retrieve parameters ---
        $params = $request->get_json_params();
        $product_identifier = sanitize_text_field($params['productIdentifier']);
        $identifier_type = sanitize_text_field($params['identifierType']);
        $affiliate_id = sanitize_text_field($params['crmAffiliateId']);

        // Optional coupon handling
        $coupon_code = isset($params['couponCode']) ? sanitize_text_field(strtoupper($params['couponCode'])) : null;
        $discount_type = isset($params['couponDiscountType']) && strtolower($params['couponDiscountType']) === 'percentage' ? 'percent' : 'fixed_cart';
        $discount_value = isset($params['couponDiscountValue']) ? floatval($params['couponDiscountValue']) : 0;

        // --- 2. Find the product ---
        $product_id = null;
        if ('id' === $identifier_type) {
            $product_id = intval($product_identifier);
        } elseif ('sku' === $identifier_type) {
            $product_id = wc_get_product_id_by_sku($product_identifier);
        }

        if (!$product_id) {
            return new WP_Error('product_not_found', 'Product could not be found with the given identifier.', ['status' => 404]);
        }
        $product = wc_get_product($product_id);
        if (!$product) {
            return new WP_Error('product_not_found', 'Product is invalid.', ['status' => 404]);
        }

        // --- 3. Create or Update the WooCommerce Coupon (if provided) ---
        $applied_coupon_code = null;
        if ($coupon_code && $discount_value > 0) {
            $coupon_id = wc_get_coupon_id_by_code($coupon_code);
            $coupon = new WC_Coupon($coupon_id ? $coupon_id : $coupon_code);

            $coupon->set_code($coupon_code);
            $coupon->set_discount_type($discount_type);
            $coupon->set_amount($discount_value);
            $coupon->set_individual_use(false);

            $product_ids_for_coupon = [$product_id];
            if ($product->is_type('variable')) {
                $product_ids_for_coupon = array_merge($product_ids_for_coupon, $product->get_children());
            }
            $coupon->set_product_ids($product_ids_for_coupon);

            $coupon->set_usage_limit(0);
            $coupon->set_exclude_sale_items(false);
            $coupon->save();

            $applied_coupon_code = $coupon->get_code();
        }

        // --- 4. Generate the unique link ID and build the URL ---
        $crmUtmLinkId = json_decode(get_option('crm_utm_link_id', '[]'), true);
        if (!is_array($crmUtmLinkId)) {
            $crmUtmLinkId = [];
        }

        $link_id = 'ULNK' . uniqid();
        $crmUtmLinkId[] = $link_id;  // Add the new link to the array

        update_option('crm_utm_link_id', json_encode($crmUtmLinkId));

        $add_to_cart_id = $product_id;
        if ($product->is_type('variable')) {
            $children_ids = $product->get_children();
            if (!empty($children_ids)) {
                $add_to_cart_id = $children_ids[0];
            }
        }

        $transient_data = [
            'add_to_cart_id' => $add_to_cart_id,
            'coupon_code' => $applied_coupon_code,
        ];

        set_transient('crm_link_' . $link_id, $transient_data, HOUR_IN_SECONDS);

        global $wpdb;
        $table_name = $wpdb->prefix . 'crm_link_clicks';

        $wpdb->insert(
            $table_name,
            [
                'link_id' => $link_id,
                'crm_affiliate_id' => $affiliate_id,
                'product_id' => $product_id,
                'coupon_code' => $applied_coupon_code,
                'created_at' => current_time('mysql'),
            ],
            [
                '%s',
                '%s',
                '%d',
                '%s',
                '%s',
            ]
        );

        $home_url = home_url('/');
        // Base arguments for the URL
        $query_args = [
            'crm_checkout_id' => $link_id,
            'utm_source' => 'crm-affiliate',
            'utm_medium' => 'referral',
            'utm_campaign' => 'aff-' . $affiliate_id,
            'utm_term' => $product_identifier,
            'utm_link_id' => $link_id,
        ];

        $shareable_link = add_query_arg($query_args, $home_url);

        // --- 5. Prepare and return the response ---
        $response_data = [
            'utmappLinkId' => $link_id,
            'shareableLink' => $shareable_link,
            'crmAffiliateId' => $affiliate_id,
            'couponProcessed' => $applied_coupon_code,
        ];

        return new WP_REST_Response($response_data, 201);
    }

    public function update_link_callback($request)
    {
        global $wpdb;
        $params = $request->get_json_params();
    
        // 1. Validate linkId
        $link_id = sanitize_text_field($params['linkId']);
        if (!$link_id) {
            return new WP_Error('missing_link_id','linkId is required',['status'=>400]);
        }
    
        // Check if the link exists
        $table_name = $wpdb->prefix . 'crm_link_clicks';
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE link_id = %s", $link_id));
        if (!$existing) {
            return new WP_Error('not_found','Link not found',['status'=>404]);
        }
    
        // 2. Handle product
        $product_identifier = sanitize_text_field($params['productIdentifier']);
        $identifier_type = sanitize_text_field($params['identifierType']);
        $affiliate_id = sanitize_text_field($params['crmAffiliateId']);
    
        $product_id = ('id' === $identifier_type)
            ? intval($product_identifier)
            : wc_get_product_id_by_sku($product_identifier);
    
        if (!$product_id) {
            return new WP_Error('product_not_found','Product could not be found.',['status'=>404]);
        }
    
        $product = wc_get_product($product_id);
        if (!$product) {
            return new WP_Error('product_not_found','Invalid product.',['status'=>404]);
        }
    
        // 3. Handle coupon logic (same as in create)
        $coupon_code = isset($params['couponCode'])
            ? sanitize_text_field(strtoupper($params['couponCode']))
            : null;
        $discount_type = (isset($params['couponDiscountType']) && strtolower($params['couponDiscountType']) === 'percentage')
            ? 'percent'
            : 'fixed_cart';
        $discount_value = isset($params['couponDiscountValue'])
            ? floatval($params['couponDiscountValue'])
            : 0;
    
        $applied_coupon_code = null;
        if ($coupon_code && $discount_value > 0) {
            // find existing coupon or create new
            $coupon_id = wc_get_coupon_id_by_code($coupon_code);
            $coupon = new WC_Coupon($coupon_id ?: $coupon_code);
    
            $coupon->set_code($coupon_code);
            $coupon->set_discount_type($discount_type);
            $coupon->set_amount($discount_value);
            $coupon->set_individual_use(false);
    
            $product_ids_for_coupon = [$product_id];
            if ($product->is_type('variable')) {
                $product_ids_for_coupon = array_merge($product_ids_for_coupon, $product->get_children());
            }
            $coupon->set_product_ids($product_ids_for_coupon);
    
            $coupon->set_usage_limit(0);
            $coupon->set_exclude_sale_items(false);
            $coupon->save();
    
            $applied_coupon_code = $coupon->get_code();
        }
    
        // 4. Update transient
        $add_to_cart_id = $product_id;
        if ($product->is_type('variable')) {
            $children = $product->get_children();
            if (!empty($children)) {
                $add_to_cart_id = $children[0];
            }
        }
    
        $transient_data = [
            'add_to_cart_id' => $add_to_cart_id,
            'coupon_code'    => $applied_coupon_code,
        ];
        set_transient('crm_link_' . $link_id, $transient_data, HOUR_IN_SECONDS);
    
        // 5. Update database row
        $wpdb->update(
            $table_name,
            [
                'coupon_code'      => $applied_coupon_code,
            ],
            ['link_id' => $link_id],
            ['%s','%d','%s','%s'],
            ['%s']
        );
    
        // 6. Generate shareable link
        $shareable_link = add_query_arg([
            'crm_checkout_id' => $link_id,
            'utm_source'      => 'crm-affiliate',
            'utm_medium'      => 'referral',
            'utm_campaign'    => 'aff-' . $affiliate_id,
            'utm_term'        => $product_identifier,
            'utm_link_id'     => $link_id,
        ], home_url('/'));
    
        return new WP_REST_Response([
            'utmappLinkId'    => $link_id,
            'shareableLink'   => $shareable_link,
            'crmAffiliateId'  => $affiliate_id,
            'couponProcessed' => $applied_coupon_code,
            'mode'            => 'updated',
        ], 200);
    }


    public function handle_custom_checkout_link()
    {
        if (!isset($_GET['crm_checkout_id'])) {
            return;
        }

        if (!function_exists('WC') || !WC()->session) {
            return;
        }

        $link_id = sanitize_text_field($_GET['crm_checkout_id']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'crm_link_clicks';

        $link_record = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE link_id = %s", $link_id));
        if (!$link_record) {
            wp_safe_redirect(home_url('/?crm_error=invalid_link'));
            exit;
        }

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE $table_name SET click_count = click_count + 1 WHERE link_id = %s",
                $link_id
            )
        );

        $add_to_cart_id = $link_record->product_id;
        $coupon_code    = $link_record->coupon_code;
        $affiliate_id   = $link_record->crm_affiliate_id;

        WC()->session->set('crm_link_id', $link_id);
        WC()->session->set('crm_affiliate_id', $affiliate_id);

        if (isset(WC()->cart)) {
            // First, clear the cart to ensure the customer only buys this specific product.
            WC()->cart->empty_cart();
    
            // Add the product (or variation) to the cart.
            WC()->cart->add_to_cart($add_to_cart_id);
    
            // If a coupon code was associated with this link, apply it.
            if (!empty($coupon_code)) {
                WC()->cart->apply_coupon($coupon_code);
            }
        }

        wp_safe_redirect(wc_get_checkout_url());
        exit;

        // $link_data = get_transient('crm_link_' . $link_id);

        // if (false === $link_data || !is_array($link_data)) {
        //     wp_safe_redirect(home_url('/'));
        //     exit;
        // }

        // WC()->session->set('crm_link_id', $link_record->link_id);
        // WC()->session->set('crm_affiliate_id', $link_record->crm_affiliate_id);

        // $add_to_cart_id = $link_data['add_to_cart_id'];
        // $coupon_code = $link_data['coupon_code'];  // This might be null

        // if (isset(WC()->cart)) {
        //     // 1. Clear the cart
        //     WC()->cart->empty_cart();

        //     // 2. Add the specific product/variation to the cart
        //     WC()->cart->add_to_cart($add_to_cart_id);

        //     // 3. Conditionally apply the coupon only if it exists
        //     if (!empty($coupon_code)) {
        //         WC()->cart->apply_coupon($coupon_code);
        //     }
        // }

        // // delete_transient('crm_link_' . $link_id);

        // wp_safe_redirect(wc_get_checkout_url());
        // exit;
    }

    public function get_link_stats_callback($request)
    {
        global $wpdb;

        // 1. Get the comma-separated string from the request parameter.
        $link_ids_str = $request->get_param('link_ids');

        // 2. Sanitize and split the string into an array of individual link IDs.
        $link_ids_arr = explode(',', $link_ids_str);

        // Sanitize each link_id in the array to prevent SQL injection.
        $sanitized_link_ids = array_map('sanitize_text_field', $link_ids_arr);

        // Filter out any empty values that might result from extra commas (e.g., "id1,,id2")
        $sanitized_link_ids = array_filter($sanitized_link_ids);

        if (empty($sanitized_link_ids)) {
            return new WP_Error(
                'no_link_ids_provided',
                'No valid link IDs were provided.',
                ['status' => 400]
            );
        }

        // 3. Prepare the database query using a WHERE IN clause.
        $table_name = $wpdb->prefix . 'crm_link_clicks';

        // Create the correct number of placeholders (%s) for the IN clause.
        $placeholders = implode(', ', array_fill(0, count($sanitized_link_ids), '%s'));

        // Prepare the full SQL query. We only need two columns.
        $sql = $wpdb->prepare(
            "SELECT link_id, click_count FROM $table_name WHERE link_id IN ($placeholders)",
            $sanitized_link_ids
        );

        // 4. Execute the query and get the results.
        // $results will be an array of objects, e.g., [ {link_id: '...', click_count: '5'}, ... ]
        $results = $wpdb->get_results($sql);

        // 5. Format the response for easy consumption.
        // We'll create a key-value map: { "link_id_1": count, "link_id_2": count }
        $formatted_stats = [];
        foreach ($results as $row) {
            $formatted_stats[] = [
                'id' => $row->link_id,
                'visit_count' => (int) $row->click_count,
            ];
        }

        $response_data = [
            'message' => 'Successfully fetched ' . count($formatted_stats) . ' visit count(s)',
            'data' => $formatted_stats
        ];

        return new WP_REST_Response($response_data, 200);
    }

    public function get_affiliate_stats_callback($request)
    {
        global $wpdb;

        // 1. Get the affiliate ID from the URL. No need to sanitize here
        // because the REST API route pattern validation already handles it.
        $affiliate_id = $request['affiliate_id'];

        // 2. Prepare the database query using SQL aggregate functions.
        $table_name = $wpdb->prefix . 'crm_link_clicks';

        // This single query gets the total number of links created
        // and the sum of all their click counts.
        $sql = $wpdb->prepare(
            "SELECT 
                COUNT(*) as total_links_generated, 
                SUM(click_count) as total_clicks 
             FROM $table_name 
             WHERE crm_affiliate_id = %s",
            $affiliate_id
        );

        // 3. Execute the query. get_row returns a single object.
        $stats = $wpdb->get_row($sql);

        // 4. Check if we got a result.
        // If the affiliate ID doesn't exist in the table, $stats will be an object
        // with NULL values for the aggregates, which is what we want.
        // We can handle this gracefully.

        $total_links = 0;
        $total_clicks = 0;

        if ($stats) {
            $total_links = (int) $stats->total_links_generated;
            // SUM() can return NULL if no rows match, so we handle that.
            $total_clicks = is_null($stats->total_clicks) ? 0 : (int) $stats->total_clicks;
        }

        // 5. Format the response data.
        $response_data = [
            'crm_affiliate_id' => $affiliate_id,
            'total_links' => $total_links,
            'total_visits' => $total_clicks,
        ];

        return new WP_REST_Response($response_data, 200);
    }

    public function trigger_order_placed_webhook($order_id)
    {
        $crm_link_id = WC()->session->get('crm_link_id');
        $crm_affiliate_id = WC()->session->get('crm_affiliate_id');

        if (!$crm_link_id && !$crm_affiliate_id)
            return;

        $order = wc_get_order($order_id);
        if ($crm_link_id) {
            $order->update_meta_data('_crm_link_id', $crm_link_id);
        }

        if ($crm_affiliate_id) {
            $order->update_meta_data('_crm_affiliate_id', $crm_affiliate_id);
        }

        $order->save();
        // Check if this is an attributed
        if (!$order || !$order->get_meta('_crm_link_id')) {
            return;
        }
        $payload = $this->prepare_order_payload($order, 'attributed_order');
        $this->send_webhook('webhook/utmapp/attributed-order', $payload);
    }

    public function trigger_order_status_webhook($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order || !$order->get_meta('_crm_link_id')) {
            return;
        }

        // Map WooCommerce statuses to your custom event types
        $status = $order->get_status();
        $event_map = [
            'completed' => 'order_delivered',
            'cancelled' => 'order_cancelled',
            'refunded' => 'order_refunded',
        ];

        if (!isset($event_map[$status])) {
            return;
        }

        $event_type = $event_map[$status];
        $payload = $this->prepare_order_payload($order, $event_type);
        $this->send_webhook('webhook/utmapp/order-event', $payload);
    }

    public function crm_check_checkout_utm_and_trigger_webhook() {
        // Only run on frontend, not in admin
        if (is_admin()) {
            return;
        }
    
        // Check if crm_checkout_id and utm_link_id are present
        if (
            isset($_GET['utm_link_id'])
        ) {
            $utm_link_id = sanitize_text_field($_GET['utm_link_id']);
    
            // Trigger webhook
            $payload = [
                'utm_link_id' => $utm_link_id
            ];
    
            $this->send_webhook('webhook/utmapp/visit-event', $payload);

        }
    }
    
    
    private function prepare_order_payload($order, $event_type)
    {
        if (!$order)
            return [];
        $line_items = [];
        foreach ($order->get_items() as $item) {
            $line_items[] = [
                'productId' => $item->get_product_id(),
                'variationId' => $item->get_variation_id(),
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'price' => (float) $item->get_total(),
            ];
        }
        return [
            'event_type' => $event_type,
            'shop_domain' => home_url('/'),
            'utmappLinkId' => $order->get_meta('_crm_link_id') ?: null,
            'crmAffiliateId' => $order->get_meta('_crm_affiliate_id') ?: null,
            'orderId' => $order->get_id(),
            'orderStatus' => $order->get_status(),
            'totalAmount' => (float) $order->get_total(),
            'currency' => $order->get_currency(),
            'customerEmail' => $order->get_billing_email(),
            'customerFirstName' => $order->get_billing_first_name(),
            'customerLastName' => $order->get_billing_last_name(),
            'lineItems' => $line_items,
            'eventTimestamp' => current_time('c', true),
        ];
    }

    private function send_webhook($endpoint_path, $payload)
    {
        $base_url = 'https://trfcs.truereff.com/wordpress';
        // $secret = get_option('crm_integration_webhook_secret');

        // if (empty($base_url) || empty($secret)) {
        //     return;
        // }

        $full_url = trailingslashit($base_url) . $endpoint_path;
        $json_payload = wp_json_encode($payload);

        // Create the signature
        // $signature = hash_hmac('sha256', $json_payload, $secret);

        $response = wp_remote_post($full_url, [
            'headers' => [
                'Content-Type' => 'application/json',
                // 'X-Wordpress-Signature' => $signature,
            ],
            'body' => $json_payload,
            'timeout' => 15,
            'blocking' => true,
        ]);

        // Optional: Log errors if needed
        if (is_wp_error($response)) {
            error_log('CRM Webhook Error: ' . $response->get_error_message());
        } else {
            error_log('Webhook sent successfully to ' . $full_url);
        }
    }

    function crm_handle_abandoned_checkout()
    {
        check_ajax_referer('crm_checkout_nonce', 'nonce');

        $form_data = $_POST;
       
        $email = '';
        if (!empty($form_data['email'])) {
            $email = sanitize_email($form_data['email']);
        } elseif (!empty($form_data['email'])) {
            $email = sanitize_email($form_data['email']);
        }
        
        if (empty($email)) {
            wp_send_json_error(['message' => 'Email is required.'], 400);
            return;
        }

        $organized_data = [
            'details' => []
        ];
    
        foreach ($form_data as $key => $value) {
            $sanitized_value = is_array($value) ? array_map('sanitize_text_field', $value) : sanitize_text_field($value);
    
            $organized_data['details'][$key] = $sanitized_value;
        }

        $payload = [
            'eventType' => 'abandoned_checkout',
            'shopUrl' => home_url('/'),
            'utmappLinkId' => WC()->session->get('crm_link_id'),
            'crmAffiliateId' => WC()->session->get('crm_affiliate_id'),
            'userId' => get_current_user_id() ?: null,
            'eventTimestamp' => current_time('c', true),
            'email' => $email,
            'formData' => $organized_data,
        ];

        $this->send_webhook('webhook/utmapp/abandoned-checkout', $payload);

        wp_send_json_success(['message' => 'Abandoned checkout webhook sent.']);
    }
}

/**
 * Begins execution of the plugin.
 */
function crm_integration_plugin_run()
{
    return CRM_Integration_Plugin::instance();
}

// Let's get this party started.
crm_integration_plugin_run();
